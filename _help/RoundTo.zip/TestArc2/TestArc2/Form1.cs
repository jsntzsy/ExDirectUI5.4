﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestArc2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static void DrawVector(Graphics g, Pen p, PointF centerPoint, PointF vector, int length = 600)
        {
            Pen pen = p.Clone() as Pen;
            pen.DashStyle = DashStyle.Dash;

            g.DrawLine(pen,
               new PointF(centerPoint.X - vector.X * length,
                centerPoint.Y - vector.Y * length),
               new PointF(centerPoint.X + vector.X * length,
                centerPoint.Y + vector.Y * length)
                );
            pen.Dispose();
        }

        public static void DrawPoint(Graphics g, Brush b, PointF point, int radius = 2)
        {
            g.FillEllipse(b, point.X - radius, point.Y - radius, radius * 2, radius * 2);
        }

        public static PointF CalculateIntersection(PointF A, PointF Va, PointF B, PointF Vb)
        {
            // 计算方向向量差
            PointF d = new PointF(A.X - B.X, A.Y - B.Y);

            // 计算参数t和s
            float t = (d.X * Vb.Y - d.Y * Vb.X) / (Va.X * Vb.Y - Va.Y * Vb.X);
            float s = (d.X * Va.Y - d.Y * Va.X) / (Va.X * Vb.Y - Va.Y * Vb.X);

            //计算交点坐标
            PointF oA1 = new PointF(A.X - t * Va.X, A.Y - t * Va.Y);
            PointF oA2 = new PointF(A.X + t * Va.X, A.Y + t * Va.Y);
            PointF oB1 = new PointF(B.X - s * Vb.X, B.Y - s * Vb.Y);
            PointF oB2 = new PointF(B.X + s * Vb.X, B.Y + s * Vb.Y);

            return oA1 == oB1 ? oA1 : oA2;
        }

        public static void DrawRoundedArc(Graphics g, PointF startPoint, PointF controlPoint, PointF endPoint, float radius)
        {
            //FIXME:注意检查三点一线和半径为0的情况

            // 计算控制点到起点和终点的向量
            PointF vectorStart = new PointF(controlPoint.X - startPoint.X, controlPoint.Y - startPoint.Y);
            PointF vectorEnd = new PointF(controlPoint.X - endPoint.X, controlPoint.Y - endPoint.Y);

            // 归一化向量
            float lengthStart = (float)Math.Sqrt(vectorStart.X * vectorStart.X + vectorStart.Y * vectorStart.Y);
            float lengthEnd = (float)Math.Sqrt(vectorEnd.X * vectorEnd.X + vectorEnd.Y * vectorEnd.Y);
            vectorStart = new PointF(vectorStart.X / lengthStart, vectorStart.Y / lengthStart);
            vectorEnd = new PointF(vectorEnd.X / lengthEnd, vectorEnd.Y / lengthEnd);

            //求∠SCE的角度
            //cos(θ) = (x1 * x2 + y1 * y2) / (sqrt(x1 ^ 2 + y1 ^ 2) * sqrt(x2 ^ 2 + y2 ^ 2))
            double cos_thta = (
                    (vectorStart.X * vectorEnd.X + vectorStart.Y * vectorEnd.Y) /
                    (Math.Sqrt(vectorStart.X * vectorStart.X + vectorStart.Y * vectorStart.Y) *
                    Math.Sqrt(vectorEnd.X * vectorEnd.X + vectorEnd.Y * vectorEnd.Y))
                );
            double alpha = Math.Acos(cos_thta);
            float radius_ = radius / (float)Math.Tan(alpha / 2);

            // 计算切点
            PointF tangentPointStart = new PointF(controlPoint.X - radius_ * vectorStart.X, controlPoint.Y - radius_ * vectorStart.Y);
            PointF tangentPointEnd = new PointF(controlPoint.X - radius_ * vectorEnd.X, controlPoint.Y - radius_ * vectorEnd.Y);

            // 计算切线方向的正交向量（即圆心到切点的向量）
            PointF normalStart = new PointF(-vectorStart.Y, vectorStart.X);
            PointF normalEnd = new PointF(vectorEnd.Y, -vectorEnd.X);

            //计算圆心
            PointF center = CalculateIntersection(
                tangentPointStart, normalStart,
                tangentPointEnd, normalEnd
                );

            // 计算起始角度和扫过的角度
            float startAngle = (float)(Math.Atan2(normalStart.Y, normalStart.X) * (180 / Math.PI));
            float endAngle = (float)(Math.Atan2(normalEnd.Y, normalEnd.X) * (180 / Math.PI));
            float sweepAngle = endAngle - startAngle;

            // 如果扫过的角度为负，增加 360 度得到正值
            if (sweepAngle <= 0)
            {
                sweepAngle += 360;
            }

            if (sweepAngle > 180)
            {
                sweepAngle = sweepAngle - 360;
            }
            // 创建一个GraphicsPath，并添加圆弧
            GraphicsPath path = new GraphicsPath();

            path.AddLine(startPoint, tangentPointStart);

            path.AddArc(
                center.X - radius, center.Y - radius,
                radius * 2, radius * 2,
                startAngle + 180, sweepAngle
                );

            path.AddLine(tangentPointEnd, endPoint);

            // 绘制路径
            g.DrawPath(Pens.Black, path);
        }

        public static void DrawRoundedArc2(Graphics g, PointF A, PointF C, PointF B, float radius)
        {
            //
            PointF midAC = new PointF((A.X + C.X) / 2, (A.Y + C.Y) / 2);
            PointF midBC = new PointF((B.X + C.X) / 2, (B.Y + C.Y) / 2);




        }


        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.HighQuality;

            //7
            PointF startPoint = new PointF(50, 100);
            PointF controlPoint = new PointF(50, 50);
            PointF endPoint = new PointF(100, 50);
            float radius = 20;
            DrawRoundedArc(g, startPoint, controlPoint, endPoint, radius);

            //8
            startPoint = new PointF(100, 50);
            controlPoint = new PointF(150, 10);
            endPoint = new PointF(200, 50);
            radius = 25;
            DrawRoundedArc(g, startPoint, controlPoint, endPoint, radius);

            //9
            startPoint = new PointF(200, 50);
            controlPoint = new PointF(250, 50);
            endPoint = new PointF(250, 100);
            radius = 10;
            DrawRoundedArc(g, startPoint, controlPoint, endPoint, radius);

            //6
            startPoint = new PointF(250, 100);
            controlPoint = new PointF(600, 175);
            endPoint = new PointF(250, 250);
            radius = 40;
            DrawRoundedArc(g, startPoint, controlPoint, endPoint, radius);

            //3
            startPoint = new PointF(250, 250);
            controlPoint = new PointF(250, 350);
            endPoint = new PointF(200, 350);
            radius = 20;
            DrawRoundedArc(g, startPoint, controlPoint, endPoint, radius);

            //2
            startPoint = new PointF(200, 350);
            controlPoint = new PointF(150, 400);
            endPoint = new PointF(100, 350);
            radius = 15;
            DrawRoundedArc(g, startPoint, controlPoint, endPoint, radius);

            //1
            startPoint = new PointF(100, 350);
            controlPoint = new PointF(50, 350);
            endPoint = new PointF(50, 250);
            radius = 25;
            DrawRoundedArc(g, startPoint, controlPoint, endPoint, radius);

            //4
            startPoint = new PointF(50, 250);
            controlPoint = new PointF(0, 150);
            endPoint = new PointF(50, 100);
            radius = 10;
            DrawRoundedArc(g, startPoint, controlPoint, endPoint, radius);

        }
    }
}
